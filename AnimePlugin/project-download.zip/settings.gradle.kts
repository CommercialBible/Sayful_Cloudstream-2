rootProject.name = "CloudStream-Extensions"

include(":MoviesShowsPlugin")
include(":AnimePlugin")
include(":MangaPlugin")
